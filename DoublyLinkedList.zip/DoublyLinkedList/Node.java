package doublylinkedlist;
public class Node{
    int data;
    Node next;
    Node prev;
    
    public Node(int data){
        this.data = data;
    }
    
    public void tampil(){
        System.out.print("("+data+")");
    }
}