package doublylinkedlist;
public class APP{
    public static void main(String[] args) {
     DoublyLinkedList list = new DoublyLinkedList();
        list.insertFirst(6);
        list.insertFirst(4);
        list.insertFirst(2);
        list.insertLast(8);
        list.insertLast(10);
        list.insertLast(12);
        list.displayForward();
        list.displayBackward();
        list.deleteFirst();
        list.deleteLast();
        list.deleteKey(12);
        list.displayForward();
        list.insertAfter(10, 14);
        list.insertAfter(14, 16);
        list.displayForward();
    }
}